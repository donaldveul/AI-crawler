from fastapi import FastAPI, Header, HTTPException
import json, yaml

app = FastAPI(
    title="AI-Ready Data Packs API",
    description="15% cheaper than AWS Data Exchange. Structured SEC risk factors for RAG.",
    version="1.0.0"
)

def load_config():
    with open('config.yaml') as f:
        return yaml.safe_load(f)

@app.get("/v1/feed")
def get_feed(x_api_key: str = Header(None)):
    if not x_api_key:
        raise HTTPException(status_code=401, detail="API key required")
    with open("data/sample_output.json") as f:
        return json.load(f)

@app.get("/v1/schema")
def get_schema():
    return {
        "schema_name": "RiskFactor",
        "fields": ["company_name", "cik", "filing_date", "risk_title", "risk_text", "category"],
        "format": "JSON array"
    }

@app.get("/pricing")
def pricing():
    cfg = load_config()
    m = cfg['monetization']
    return {
        "plan": "AI-Ready SEC Risk Factors",
        "price_monthly_usd": m['your_price_monthly'],
        "competitor_price_usd": m['competitor_price_monthly'],
        "discount": m['discount'],
        "value_prop": m['value_prop'],
        "sla": cfg['api']['sla']
    }

@app.get("/health")
def health():
    return {"status": "ok"}
